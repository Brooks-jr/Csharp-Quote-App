using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using DbConnection;
using MySql.Data.MySqlClient;


namespace databaseASP.Controllers
{
    public class HomeController : Controller
    {
        private DbConnector connect;

        public HomeController()
        {
            connect = new DbConnector();
        }

        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
        
        return View();
        }
//  --------------------------------------------------------------------       
//  --------------------------------------------------------------------       
        [HttpPost]
        [Route("addQuotes")]
        public IActionResult addQuote(string name, string quote)
        {
            string query = $"INSERT INTO users (name, quote) VALUES ('{name}', '{quote}')";
            DbConnector.Execute(query);
        // List<Dictionary<string, object>> AllUsers = DbConnector.Query("SELECT * FROM users");
        // Other code
        return RedirectToAction("Index");
        }
//  --------------------------------------------------------------------       
//  --------------------------------------------------------------------       
        
        [HttpGet]
        [Route("quotes")]
        public IActionResult seeQuote()
        {
        string query = "SELECT * FROM users";
        var allQuotes = DbConnector.Query(query);
        ViewBag.allQuotes = allQuotes;
        
        // Other code
        return View("quotes");
        }
    }
}
